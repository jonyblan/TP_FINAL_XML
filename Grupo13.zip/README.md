# How to run
## Requirements
- Java Runtime Enviroment: run ```sudo apt-get install default-jre``` on command line
- Java JDK: run ```sudo apt-get install default-jdk``` on command line
- BaseX: run ```sudo apt-get install basex``` on command line
- Apache FOP: run ```sudo apt-get install fop``` on command line
## Command line
```./tpe.sh [year] [type]```\
year must be an integer between 2013 and 2024\
type must be one of sc, xf, cw, go, mc